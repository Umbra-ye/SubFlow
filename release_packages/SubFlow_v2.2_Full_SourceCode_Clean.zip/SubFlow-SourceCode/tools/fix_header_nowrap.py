#!/usr/bin/env python3
# -*- coding: utf-8 -*-

file_path = r"E:\杂乱项目gemini\SubConverter-Extended\web\index.html"
with open(file_path, "r", encoding="utf-8") as f:
    c = f.read()

# 1. 扩大 app-container 宽度为 960px，给现代大屏和工作台足够的呼吸空间
c = c.replace(
    "max-width: 820px;",
    "max-width: 960px;"
)

# 2. 规整 .header、.brand、.brand-title、.brand-status
old_header_css = """    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding-bottom: 8px;
    }

    .header-controls {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: nowrap;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
    }"""

new_header_css = """    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding-bottom: 8px;
    }

    .header-controls {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: nowrap !important;
      flex-shrink: 0 !important;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-shrink: 0 !important;
      white-space: nowrap !important;
    }

    .brand-title {
      font-size: 1.12rem;
      font-weight: 700;
      letter-spacing: -0.02em;
      color: var(--text-primary);
      white-space: nowrap !important;
    }

    .brand-status {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.78rem;
      color: var(--emerald);
      font-weight: 500;
      white-space: nowrap !important;
    }"""

if old_header_css in c:
    c = c.replace(old_header_css, new_header_css)
    print("Replaced header CSS")
else:
    print("old_header_css not found")

# 3. 规整 .segmented-nav 与 .nav-btn
old_nav_css = """    .nav-btn {
      position: relative;
      background: transparent;
      border: none;
      color: var(--text-secondary);
      font-family: inherit;
      font-size: 0.85rem;
      font-weight: 600;
      padding: 7px 16px;
      border-radius: calc(var(--radius-md) - 2px);
      cursor: pointer;
      transition: color var(--duration-fast) var(--ease-out);
      z-index: 1;
    }"""

new_nav_css = """    .segmented-nav {
      position: relative;
      background: var(--bg-surface);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      padding: 3px;
      display: inline-flex !important;
      align-items: center !important;
      gap: 4px;
      flex-shrink: 0 !important;
    }

    .nav-btn {
      position: relative;
      background: transparent;
      border: none;
      color: var(--text-secondary);
      font-family: inherit;
      font-size: 0.84rem;
      font-weight: 600;
      padding: 6px 14px !important;
      border-radius: calc(var(--radius-md) - 2px);
      cursor: pointer;
      transition: color var(--duration-fast) var(--ease-out);
      z-index: 1;
      white-space: nowrap !important;
      flex-shrink: 0 !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }"""

if old_nav_css in c:
    c = c.replace(old_nav_css, new_nav_css)
    print("Replaced nav CSS")
else:
    print("old_nav_css not found")

with open(file_path, "w", encoding="utf-8") as f:
    f.write(c)

print("Saved updated index.html!")
