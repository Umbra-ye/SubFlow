# -*- coding: utf-8 -*-
import os
import re

def update_index_html():
    p = 'web/index.html'
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()

    # 1. 彻底删除 256位加盐保护
    target_pwd_label = '''<label style="display:flex; justify-content:space-between; font-size:0.8rem; color:var(--text-secondary); margin-bottom:6px; font-weight:600;">
              <span>安全密码</span>
              <span style="font-size:0.7rem; color:var(--text-muted);">256位加盐保护</span>
            </label>'''
    clean_pwd_label = '''<label style="display:block; font-size:0.8rem; color:var(--text-secondary); margin-bottom:6px; font-weight:600;">登录密码</label>'''

    if target_pwd_label in c:
        c = c.replace(target_pwd_label, clean_pwd_label)
        print("Removed '256位加盐保护' from index.html")
    else:
        # Fallback regex
        c = re.sub(r'<span[^>]*>256位加盐保护</span>', '', c)
        print("Removed 256位加盐保护 via regex fallback")

    # 2. 彻底删除 租户独立私有隔离 营销虚饰
    target_banner = '''<div style="display:flex; align-items:center; justify-content:space-between; padding:8px 12px; background:rgba(255,255,255,0.025); border:1px dashed rgba(255,255,255,0.08); border-radius:10px; font-size:0.75rem;">
            <div style="display:flex; align-items:center; gap:6px; color:var(--text-secondary);">
              <span>⚡</span>
              <span>租户独立私有隔离</span>
            </div>
            <span style="color:#38bdf8; cursor:pointer; font-weight:600;" onclick="switchGateTab('register')">初次使用？点击新建 →</span>
          </div>'''
    clean_banner = '''<div style="text-align:right; font-size:0.8rem; padding: 4px 0;">
            <span style="color:#38bdf8; cursor:pointer; font-weight:600;" onclick="switchGateTab('register')">初次使用？点击新建账号 →</span>
          </div>'''

    if target_banner in c:
        c = c.replace(target_banner, clean_banner)
        print("Removed '租户独立私有隔离' from index.html")
    else:
        c = re.sub(r'<span>⚡</span>\s*<span>租户独立私有隔离</span>', '', c)
        print("Removed 租户独立私有隔离 via regex")

    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)

def update_admin_html():
    p = 'web/admin.html'
    with open(p, 'r', encoding='utf-8') as f:
        c = f.read()

    # 1. 在 nav-actions 加入修改账密按钮
    old_nav = '''      <div class="nav-actions">
        <a href="/" class="btn-outline">'''
    new_nav = '''      <div class="nav-actions">
        <button class="btn-outline" onclick="openAdminSecurityModal()" style="margin-right: 8px;"><span>🔐</span> <span>修改管理账密</span></button>
        <a href="/" class="btn-outline">'''

    if old_nav in c and 'openAdminSecurityModal' not in c:
        c = c.replace(old_nav, new_nav, 1)
        print("Added '修改管理账密' button to admin nav")

    # 2. 在 overview 概览加入 管理员安全与访问控制 卡片
    target_diag_card = '''          <div class="card-title">
            <span>⚡ 系统健康体检与基准网络</span>'''
    
    admin_sec_card = '''        <!-- 管理员安全凭据卡片 -->
        <div class="glass-card" style="margin-bottom: 20px;">
          <div class="card-title">
            <span style="display: flex; align-items: center; gap: 8px;">🔐 管理员账号与访问安全</span>
            <button class="btn-primary" onclick="openAdminSecurityModal()">修改管理账密</button>
          </div>
          <div style="display:flex; flex-direction:column; gap:12px; font-size:0.85rem;">
            <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
              <span style="color:var(--text-muted);">当前登录账号</span>
              <strong id="card-admin-user" style="color:var(--text-primary); font-family: var(--font-mono);">admin</strong>
            </div>
            <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
              <span style="color:var(--text-muted);">系统角色权限</span>
              <span style="color:#10b981; font-weight: 600;">超级系统管理员 (Root Admin)</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:8px 0;">
              <span style="color:var(--text-muted);">安全操作</span>
              <span style="color:var(--text-dim);">支持随时更换管理员登录账号名与访问密码</span>
            </div>
          </div>
        </div>

        <div class="glass-card">
          <div class="card-title">
            <span>⚡ 系统健康体检与基准网络</span>'''

    if target_diag_card in c and 'card-admin-user' not in c:
        c = c.replace(target_diag_card, admin_sec_card, 1)
        print("Added admin security card to admin overview")

    # 3. 加入修改账密弹窗与 JS
    modal_and_js = '''
    <!-- 管理员安全凭据设置弹窗 -->
    <div id="admin-security-modal" class="modal-backdrop" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.65); backdrop-filter: blur(8px); z-index: 9999; align-items: center; justify-content: center;">
      <div class="glass-card" style="width: 100%; max-width: 440px; padding: 24px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.12); box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.4rem;">🔐</span>
            <h3 style="margin: 0; font-size: 1.15rem; color: #fff;">修改管理员账号与密码</h3>
          </div>
          <button style="background: none; border: none; color: var(--text-muted); font-size: 1.4rem; cursor: pointer;" onclick="closeAdminSecurityModal()">&times;</button>
        </div>
        
        <div style="margin-bottom: 14px;">
          <label style="display: block; font-size: 0.8rem; color: var(--text-muted); margin-bottom: 6px;">当前登录账号</label>
          <input type="text" id="admin-cur-name-input" class="modern-input" disabled style="width: 100%; padding: 10px 12px; border-radius: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: var(--text-muted); cursor: not-allowed;">
        </div>

        <div style="margin-bottom: 14px;">
          <label style="display: block; font-size: 0.8rem; color: var(--text-muted); margin-bottom: 6px;">新管理员账号 <span style="color:var(--text-dim); font-size: 0.75rem;">(留空则保持原账号不变)</span></label>
          <input type="text" id="admin-new-user-input" class="modern-input" placeholder="输入新的管理员账号名 (至少 3 位)" style="width: 100%; padding: 10px 12px; border-radius: 8px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff;">
        </div>

        <div style="margin-bottom: 14px;">
          <label style="display: block; font-size: 0.8rem; color: var(--text-muted); margin-bottom: 6px;">新登录密码 <span style="color:var(--text-dim); font-size: 0.75rem;">(留空则保持原密码不变)</span></label>
          <input type="password" id="admin-new-pwd-input" class="modern-input" placeholder="输入新密码 (至少 6 位)" style="width: 100%; padding: 10px 12px; border-radius: 8px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff;">
        </div>

        <div style="margin-bottom: 18px;">
          <label style="display: block; font-size: 0.8rem; color: var(--text-muted); margin-bottom: 6px;">再次确认新密码</label>
          <input type="password" id="admin-confirm-pwd-input" class="modern-input" placeholder="再次输入新密码确认" style="width: 100%; padding: 10px 12px; border-radius: 8px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.15); color: #fff;">
        </div>

        <div id="admin-sec-alert" style="display: none; padding: 10px 14px; border-radius: 8px; font-size: 0.85rem; margin-bottom: 16px;"></div>

        <div style="display: flex; gap: 12px; justify-content: flex-end;">
          <button class="btn-outline" onclick="closeAdminSecurityModal()">取消</button>
          <button class="btn-primary" id="btn-save-admin-sec" onclick="submitAdminCredentials()">确认保存修改</button>
        </div>
      </div>
    </div>

    <script>
    function openAdminSecurityModal() {
      const modal = document.getElementById('admin-security-modal');
      if (modal) {
        modal.style.display = 'flex';
        const cur = localStorage.getItem('subflow_admin_username') || 'admin';
        document.getElementById('admin-cur-name-input').value = cur;
        document.getElementById('admin-new-user-input').value = '';
        document.getElementById('admin-new-pwd-input').value = '';
        document.getElementById('admin-confirm-pwd-input').value = '';
        const alertBox = document.getElementById('admin-sec-alert');
        if (alertBox) alertBox.style.display = 'none';
      }
    }

    function closeAdminSecurityModal() {
      const modal = document.getElementById('admin-security-modal');
      if (modal) modal.style.display = 'none';
    }

    async function submitAdminCredentials() {
      const newUser = document.getElementById('admin-new-user-input').value.trim();
      const newPwd = document.getElementById('admin-new-pwd-input').value;
      const confirmPwd = document.getElementById('admin-confirm-pwd-input').value;
      const alertBox = document.getElementById('admin-sec-alert');
      const btn = document.getElementById('btn-save-admin-sec');

      if (!newUser && !newPwd) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
        alertBox.style.color = '#ef4444';
        alertBox.innerText = '新账号名与新密码不能同时为空';
        return;
      }

      if (newPwd && newPwd !== confirmPwd) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
        alertBox.style.color = '#ef4444';
        alertBox.innerText = '两次输入的新密码不一致，请重新检查';
        return;
      }

      if (newPwd && newPwd.length < 6) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
        alertBox.style.color = '#ef4444';
        alertBox.innerText = '新密码长度至少需要 6 位';
        return;
      }

      btn.disabled = true;
      btn.innerText = '保存中...';

      try {
        const res = await fetch('/api/admin/change-credentials', {
          method: 'POST',
          headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
          body: JSON.stringify({ new_username: newUser, new_password: newPwd })
        });
        const d = await res.json();
        if (res.ok && d.ok) {
          alertBox.style.display = 'block';
          alertBox.style.background = 'rgba(16, 185, 129, 0.2)';
          alertBox.style.color = '#10b981';
          alertBox.innerText = d.message || '管理员账号密码修改成功！';
          if (d.token) {
            localStorage.setItem('subflow_admin_token', d.token);
          }
          if (d.username) {
            localStorage.setItem('subflow_admin_username', d.username);
            const cardUser = document.getElementById('card-admin-user');
            if (cardUser) cardUser.innerText = d.username;
          }
          setTimeout(() => {
            closeAdminSecurityModal();
            btn.disabled = false;
            btn.innerText = '确认保存修改';
          }, 1200);
        } else {
          alertBox.style.display = 'block';
          alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
          alertBox.style.color = '#ef4444';
          alertBox.innerText = d.error || '修改失败，请重试';
          btn.disabled = false;
          btn.innerText = '确认保存修改';
        }
      } catch (e) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
        alertBox.style.color = '#ef4444';
        alertBox.innerText = '网络请求异常: ' + e.message;
        btn.disabled = false;
        btn.innerText = '确认保存修改';
      }
    }
    </script>
</body>
'''
    if '</body>' in c and 'admin-security-modal' not in c:
        c = c.replace('</body>', modal_and_js)
        print("Injected admin-security-modal and JS into admin.html")

    with open(p, 'w', encoding='utf-8') as f:
        f.write(c)

def update_gateways():
    api_code = '''        # 11.1 管理员修改自身账密 (/api/admin/change-credentials)
        if path == "/api/admin/change-credentials":
            user = self.get_current_user()
            if not user or user["role"] != "admin":
                self.send_json({"error": "Forbidden: Requires admin privileges"}, code=403)
                return
            new_username = body.get("new_username", "").strip()
            new_password = body.get("new_password", "").strip()

            if not new_username and not new_password:
                self.send_json({"error": "新账号与新密码不能同时为空"}, code=400)
                return

            with db_lock:
                conn = get_db()
                c = conn.cursor()
                if new_username:
                    if len(new_username) < 3:
                        conn.close()
                        self.send_json({"error": "账号名称至少 3 个字符"}, code=400)
                        return
                    c.execute("SELECT id FROM users WHERE username = ? AND id != ?;", (new_username, user["id"]))
                    if c.fetchone():
                        conn.close()
                        self.send_json({"error": "该账号已被占用，请使用其他账号名"}, code=400)
                        return
                    c.execute("UPDATE users SET username = ? WHERE id = ?;", (new_username, user["id"]))

                if new_password:
                    if len(new_password) < 6:
                        conn.close()
                        self.send_json({"error": "新密码至少 6 个字符"}, code=400)
                        return
                    new_hash, new_salt = hash_password(new_password)
                    c.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?;", (new_hash, new_salt, user["id"]))

                conn.commit()
                c.execute("SELECT id, username, role FROM users WHERE id = ?;", (user["id"],))
                updated_row = c.fetchone()
                conn.close()

            new_token = generate_jwt(updated_row["id"], updated_row["username"], updated_row["role"])
            self.send_json({
                "ok": True,
                "message": "管理员账号与密码已成功更新",
                "token": new_token,
                "username": updated_row["username"]
            })
            return

'''
    for path in ['gateway.py', 'linux/gateway.py']:
        with open(path, 'r', encoding='utf-8') as f:
            c = f.read()
        target = '# 11. '
        if target in c and '/api/admin/change-credentials' not in c:
            c = c.replace(target, api_code + '        # 11. ')
            with open(path, 'w', encoding='utf-8') as f:
                f.write(c)
            print("Added /api/admin/change-credentials to", path)

def main():
    update_index_html()
    update_admin_html()
    update_gateways()
    print("ALL CLEANUP & ADMIN FEATURES APPLIED!")

if __name__ == '__main__':
    main()
