#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import re

def patch_index_html():
    html_path = r"E:\杂乱项目gemini\SubConverter-Extended\web\index.html"
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. 注入现代扁平化按钮与操作栏规范 CSS
    flat_css = """
    /* ==========================================================================
       Linear & Vercel 极简扁平化现代按钮与操作栏规范 (统一高与微交互)
       ========================================================================== */
    .card-action-bar, .history-actions {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      justify-content: flex-end;
      flex-shrink: 0;
    }

    .action-btn {
      height: 30px !important;
      line-height: 28px !important;
      box-sizing: border-box !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      gap: 5px !important;
      padding: 0 10px !important;
      border-radius: 6px !important;
      font-family: inherit !important;
      font-size: 0.78rem !important;
      font-weight: 600 !important;
      white-space: nowrap !important;
      cursor: pointer !important;
      transition: all 0.15s cubic-bezier(0.16, 1, 0.3, 1) !important;
      border: 1px solid var(--border-subtle) !important;
      background: var(--bg-surface-elevated) !important;
      color: var(--text-secondary) !important;
      flex-shrink: 0 !important;
      user-select: none !important;
    }
    .action-btn:hover {
      background: var(--bg-surface-hover) !important;
      border-color: var(--border-hover) !important;
      color: var(--text-primary) !important;
    }
    .action-btn.primary {
      background: var(--primary) !important;
      border-color: var(--primary) !important;
      color: #ffffff !important;
    }
    .action-btn.primary:hover {
      background: var(--primary-hover) !important;
      border-color: var(--primary-hover) !important;
    }
    .action-btn.danger {
      color: #f87171 !important;
      border-color: rgba(248, 113, 113, 0.25) !important;
      background: rgba(248, 113, 113, 0.06) !important;
    }
    .action-btn.danger:hover {
      background: rgba(248, 113, 113, 0.16) !important;
      border-color: rgba(248, 113, 113, 0.5) !important;
      color: #ef4444 !important;
    }

    /* 批量操作工具栏 */
    .batch-merge-bar {
      display: none;
      align-items: center;
      justify-content: space-between;
      background: var(--bg-surface-elevated);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      padding: 8px 14px;
      margin: 0 0 12px 0;
      gap: 10px;
      flex-wrap: wrap;
    }

    [data-theme="light"] .batch-merge-bar {
      background: #f8fafc !important;
      border: 1px solid #e2e8f0 !important;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
    }
    [data-theme="light"] .action-btn {
      background: #ffffff !important;
      border-color: #e2e8f0 !important;
      color: #475569 !important;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03) !important;
    }
    [data-theme="light"] .action-btn:hover {
      background: #f8fafc !important;
      border-color: #cbd5e1 !important;
      color: #0f172a !important;
    }
    [data-theme="light"] .action-btn.primary {
      background: #0f172a !important;
      border-color: #0f172a !important;
      color: #ffffff !important;
      box-shadow: 0 1px 3px rgba(15, 23, 42, 0.12) !important;
    }
    [data-theme="light"] .action-btn.primary:hover {
      background: #1e293b !important;
      border-color: #1e293b !important;
    }
    [data-theme="light"] .action-btn.danger {
      color: #dc2626 !important;
      background: #fef2f2 !important;
      border-color: #fecaca !important;
    }
    [data-theme="light"] .action-btn.danger:hover {
      background: #fee2e2 !important;
      border-color: #fca5a5 !important;
      color: #b91c1c !important;
    }
"""
    if ".card-action-bar" not in content:
        content = content.replace("  </style>", flat_css + "\n  </style>")

    # 2. 规整顶栏按钮 CSS，彻底杜绝换行，统一高度 34px
    content = re.sub(
        r'\.theme-toggle-btn\s*\{[^}]+\}',
        '''.theme-toggle-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: var(--bg-surface);
      border: 1px solid var(--border-subtle);
      border-radius: 8px;
      padding: 0 12px;
      height: 34px !important;
      line-height: 32px !important;
      box-sizing: border-box !important;
      color: var(--text-secondary);
      font-family: inherit;
      font-size: 0.84rem;
      font-weight: 600;
      cursor: pointer;
      transition: all var(--duration-fast) var(--ease-out);
      user-select: none;
      white-space: nowrap !important;
      flex-shrink: 0 !important;
    }''',
        content,
        count=1
    )

    content = re.sub(
        r'\.auth-pill-btn\s*\{[^}]+\}',
        '''.auth-pill-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 0 12px;
      height: 34px !important;
      line-height: 32px !important;
      box-sizing: border-box !important;
      border-radius: 8px !important;
      font-size: 0.82rem;
      font-weight: 600;
      color: var(--text-primary);
      background: var(--bg-surface-elevated);
      border: 1px solid var(--border-subtle);
      cursor: pointer;
      transition: all var(--duration-fast) var(--ease-out);
      user-select: none;
      white-space: nowrap !important;
      flex-shrink: 0 !important;
    }''',
        content,
        count=1
    )

    # 3. 规整 history 头部操作栏按钮 (全量一键测活 & 紧急作废旧链接)
    old_header_btns = '''            <button class="secondary-btn emerald" id="btn-ping-all" onclick="pingAllHistory()">🔄 全量一键测活</button>
            <button class="secondary-btn" id="btn-emergency-kill" style="color:#ef4444; border-color:rgba(239,68,68,0.35); background:rgba(239,68,68,0.08); font-size:0.78rem; padding:6px 12px; font-weight:600; cursor:pointer;" onclick="triggerEmergencyKill()" title="断开公网穿透并重置防盗密钥，彻底作废所有外泄链接">🚨 紧急作废旧链接</button>'''
    
    new_header_btns = '''            <button class="action-btn" id="btn-ping-all" onclick="pingAllHistory()">🔄 全量一键测活</button>
            <button class="action-btn danger" id="btn-emergency-kill" onclick="triggerEmergencyKill()" title="断开公网穿透并重置防盗密钥，彻底作废所有外泄链接">🚨 紧急作废旧链接</button>'''
    
    if old_header_btns in content:
        content = content.replace(old_header_btns, new_header_btns)

    # 4. 规整 batch-merge-bar 批量操作栏 HTML
    old_batch_bar_prefix = '<div id="batch-merge-bar" style="display:none; align-items:center; justify-content:space-between; background:linear-gradient(135deg, rgba(30, 27, 75, 0.5) 0%, rgba(15, 23, 42, 0.7) 100%); border:1px solid rgba(168, 85, 247, 0.35); border-radius:10px; padding:10px 16px; margin: 0 0 14px 0; gap:12px; flex-wrap:wrap; box-shadow: 0 4px 16px rgba(0,0,0,0.2);">'
    new_batch_bar_prefix = '<div id="batch-merge-bar" class="batch-merge-bar">'
    if old_batch_bar_prefix in content:
        content = content.replace(old_batch_bar_prefix, new_batch_bar_prefix)

    old_batch_actions = '''          <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
            <button class="primary-btn" id="batch-btn-save" style="padding:6px 14px; font-size:0.78rem; background:linear-gradient(135deg, #8b5cf6, #6366f1); border-color:#8b5cf6;" onclick="saveSelectedAsMergedCard()">💾 保存为聚合卡片</button>
            <button class="primary-btn" id="batch-btn-copy" style="padding:6px 14px; font-size:0.78rem;" onclick="copyMergedSelected()">🔗 复制合并总订阅</button>
            <button class="secondary-btn" id="batch-btn-flclash" style="padding:6px 12px; font-size:0.78rem; color:#38bdf8; border-color:rgba(56,189,248,0.4);" onclick="importMergedToFlClash()">🚀 导入 FlClash</button>
            <button class="secondary-btn" id="batch-btn-preview" style="padding:6px 12px; font-size:0.78rem; color:#a78bfa; border-color:rgba(167,139,250,0.4);" onclick="previewMergedSelected()">👀 预览节点</button>
            <button class="secondary-btn" id="batch-btn-cancel" style="padding:6px 10px; font-size:0.78rem;" onclick="clearBatchSelection()">✕ 取消</button>
          </div>'''
    
    new_batch_actions = '''          <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
            <button class="action-btn primary" id="batch-btn-copy" onclick="copyMergedSelected()">🔗 复制合并总订阅</button>
            <button class="action-btn" id="batch-btn-save" onclick="saveSelectedAsMergedCard()">💾 保存为聚合卡片</button>
            <button class="action-btn" id="batch-btn-flclash" onclick="importMergedToFlClash()">🚀 导入 FlClash</button>
            <button class="action-btn" id="batch-btn-preview" onclick="previewMergedSelected()">👀 预览节点</button>
            <button class="action-btn" id="batch-btn-cancel" onclick="clearBatchSelection()">✕ 取消</button>
          </div>'''
    if old_batch_actions in content:
        content = content.replace(old_batch_actions, new_batch_actions)

    # 5. 修复 copyHistoryConvertedUrl 中的 127.0.0.1 硬编码
    old_copy_func = """    function copyHistoryConvertedUrl(sourceUrl, targetFormat = 'auto', forceRemote = false) {
      let baseUrl = (forceRemote && isTunnelRunning && currentTunnelUrl) ? currentTunnelUrl : 'http://127.0.0.1:25588';
      let convertedUrl = `${baseUrl}/sub?target=${targetFormat}&url=${encodeURIComponent(sourceUrl)}`;
      if (currentServerPin) convertedUrl += `&pin=${encodeURIComponent(currentServerPin)}`;
      navigator.clipboard.writeText(convertedUrl).then(() => {
        let msg = forceRemote ? '🌐 已复制公网远端转换链接！' : '📋 已复制万能转换链接！Clash / v2rayN 均可秒刷！';
        if (targetFormat === 'clash') msg = forceRemote ? '🌐 已复制 Clash 公网转换链接！' : '📋 已复制 Clash 专属转换链接！';
        else if (targetFormat === 'mixed') msg = forceRemote ? '🌐 已复制 v2rayN 公网转换链接！' : '📋 已复制 v2rayN 专属转换链接！';
        showSonnerToast(msg);
      });
      try {
        fetch(apiUrl(`/api/save-alias?id=auto&url=${encodeURIComponent(sourceUrl)}`)).catch(() => {});
      } catch (e) {}
    }"""

    new_copy_func = """    function copyHistoryConvertedUrl(sourceUrl, targetFormat = 'auto', forceRemote = false) {
      let baseUrl = (forceRemote && isTunnelRunning && currentTunnelUrl) ? currentTunnelUrl : getEffectiveBaseUrl();
      let convertedUrl = `${baseUrl}/sub?target=${targetFormat}&url=${encodeURIComponent(sourceUrl)}`;
      if (currentServerPin) convertedUrl += `&pin=${encodeURIComponent(currentServerPin)}`;
      navigator.clipboard.writeText(convertedUrl).then(() => {
        let msg = currentAppLang === 'en' ? '📋 Converted link copied!' : '📋 已复制转换链接！客户端可直接粘贴！';
        showSonnerToast(msg);
      }).catch(() => {
        showSonnerToast(currentAppLang === 'en' ? '⚠️ Failed to copy' : '⚠️ 复制失败，请手动选择复制');
      });
      try {
        fetch(apiUrl(`/api/save-alias?id=auto&url=${encodeURIComponent(sourceUrl)}`)).catch(() => {});
      } catch (e) {}
    }"""
    if old_copy_func in content:
        content = content.replace(old_copy_func, new_copy_func)

    # 6. 修复 importHistoryToFlClash 与 importToFlClash 深度链接唤醒与剪贴板兜底
    old_import_hist = """    function importHistoryToFlClash(airportUrl) {
      const clashUrl = `${getEffectiveBaseUrl()}/sub?target=clash&url=${encodeURIComponent(airportUrl)}&udp=true&scv=true`;
      showSonnerToast('🚀 正在一键唤醒 FlClash 导入此订阅...');
      fetch(apiUrl(`/api/import-flclash?url=${encodeURIComponent(clashUrl)}`))
        .then(r => r.json())
        .then(data => {
          if (data.ok) {
            showSonnerToast('✅ 已唤醒 FlClash！请在弹出的窗口中点击确认保存。');
          } else {
            window.location.href = `clash://install-config?url=${encodeURIComponent(clashUrl)}&name=SubFlow`;
          }
        })
        .catch(() => {
          window.location.href = `clash://install-config?url=${encodeURIComponent(clashUrl)}&name=SubFlow`;
        });
    }"""

    new_import_hist = """    function importHistoryToFlClash(airportUrl) {
      const clashUrl = `${getEffectiveBaseUrl()}/sub?target=clash&url=${encodeURIComponent(airportUrl)}&udp=true&scv=true`;
      
      // 1. 同步静默拷入系统剪贴板 (双重保险兜底)
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(clashUrl).catch(() => {});
      }

      // 2. 原生物理超链接模拟点击 (防现代浏览器安全策略阻拦协议)
      try {
        const a = document.createElement('a');
        a.href = `clash://install-config?url=${encodeURIComponent(clashUrl)}&name=SubFlow`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      } catch (e) {
        window.location.href = `clash://install-config?url=${encodeURIComponent(clashUrl)}&name=SubFlow`;
      }

      showSonnerToast(currentAppLang === 'en'
        ? '🚀 Launching FlClash / Clash... (Link copied to clipboard as fallback)'
        : '🚀 正在唤醒 FlClash / Clash 客户端... (链接已同步复制兜底)');
    }"""
    if old_import_hist in content:
        content = content.replace(old_import_hist, new_import_hist)

    # 7. 修复 probeRealSubscription 中的真实流量与到期时间解析
    probe_pattern = r'async function probeRealSubscription\(id, subUrl\) \{[\s\S]*?renderHistoryList\(\);\s*\}\s*\}'
    new_probe_func = """async function probeRealSubscription(id, subUrl) {
      const idx = historyList.findIndex(h => h.id === id);
      if (idx < 0) return;
      const startTime = performance.now();
      try {
        const testTarget = `${getEffectiveBaseUrl()}/sub?target=clash&url=${encodeURIComponent(subUrl)}`;
        const res = await fetch(testTarget, { method: 'GET' });
        const latencyMs = Math.round(performance.now() - startTime);
        if (res.ok) {
          const text = await res.text();
          let count = 0;
          let inProxies = false;
          const lines = text.split('\\n');
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line === 'proxies:') { inProxies = true; continue; }
            if (inProxies) {
              if (line.startsWith('proxy-groups:') || line.startsWith('rules:')) break;
              if (line.startsWith('- name:')) count++;
            }
          }
          if (count === 0) {
            count = lines.filter(l => l.trim() && !l.trim().startsWith('#') && (l.includes('://') || l.length > 20)).length;
          }
          historyList[idx].nodeCount = count > 0 ? count : 1;
          historyList[idx].latency = latencyMs;
          historyList[idx].status = 'online';

          const userInfo = res.headers.get('subscription-userinfo');
          if (userInfo) {
            const up = parseInt((userInfo.match(/upload=(\\d+)/) || [0,0])[1]);
            const down = parseInt((userInfo.match(/download=(\\d+)/) || [0,0])[1]);
            const total = parseInt((userInfo.match(/total=(\\d+)/) || [0,0])[1]);
            const exp = parseInt((userInfo.match(/expire=(\\d+)/) || [0,0])[1]);
            if (total > 0) {
              const remGB = Math.max(0, (total - up - down) / 1073741824).toFixed(1);
              const totalGB = (total / 1073741824).toFixed(0);
              historyList[idx].remTraffic = `${remGB} GB / ${totalGB} GB`;
            } else {
              historyList[idx].remTraffic = currentAppLang === 'en' ? 'Unlimited' : '不限流量';
            }
            if (exp > 0) {
              historyList[idx].expire = new Date(exp * 1000).toISOString().split('T')[0];
            } else {
              historyList[idx].expire = currentAppLang === 'en' ? 'Permanent' : '长期有效';
            }
          } else {
            // 上游没有下发 Subscription-Userinfo 头，说明无流量/日期限制！
            historyList[idx].remTraffic = currentAppLang === 'en' ? 'Unlimited' : '不限流量';
            historyList[idx].expire = currentAppLang === 'en' ? 'Permanent' : '长期有效';
          }
          try { localStorage.setItem('subflow_history', JSON.stringify(historyList)); } catch(e) {}
          renderHistoryList();
        } else {
          historyList[idx].status = 'offline';
          renderHistoryList();
        }
      } catch (e) {
        historyList[idx].status = 'offline';
        renderHistoryList();
      }
    }"""
    content = re.sub(probe_pattern, lambda m: new_probe_func, content, count=1)

    # 8. 重构 renderHistoryList 中的卡片布局与 action-btn
    old_card_actions = """            <div class="history-actions" style="display:flex; gap:6px; flex-wrap:wrap; align-items:center; min-width:180px; justify-content:flex-end;">
              <button class="primary-btn" style="padding:6px 12px; font-size:0.8rem;" onclick="copyHistoryConvertedUrl('${item.url}', 'auto')" title="${dict.btnCopyConverted}">${dict.btnCopyConverted}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#38bdf8; border-color:rgba(56,189,248,0.4);" onclick="importHistoryToFlClash('${item.url}')">${dict.btnImportCardFlclash}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#a78bfa; border-color:rgba(167,139,250,0.4);" onclick="previewHistoryItem('${item.url}')">${dict.btnPreviewCard}</button>
              <button class="secondary-btn emerald" style="padding:6px 10px; font-size:0.8rem;" onclick="loadHistoryItem('${item.url}')">${dict.btnLoadEdit}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#f87171; border-color:rgba(248,113,113,0.3);" onclick="deleteHistoryItem(${idx})">${dict.btnDelete}</button>
            </div>"""

    new_card_actions = """            <div class="card-action-bar">
              <button class="action-btn primary" onclick="copyHistoryConvertedUrl('${item.url}', 'auto')" title="${dict.btnCopyConverted}">📋 <span>${dict.btnCopyConverted}</span></button>
              <button class="action-btn" onclick="importHistoryToFlClash('${item.url}')" title="${dict.btnImportCardFlclash}">🚀 <span>${dict.btnImportCardFlclash}</span></button>
              <button class="action-btn" onclick="loadHistoryItem('${item.url}')" title="${dict.btnLoadEdit}">⚡ <span>${dict.btnLoadEdit}</span></button>
              <button class="action-btn" onclick="previewHistoryItem('${item.url}')" title="${dict.btnPreviewCard}">👀 <span>${dict.btnPreviewCard}</span></button>
              <button class="action-btn danger" onclick="deleteHistoryItem(${idx})" title="${dict.btnDelete}">🗑️ <span>${dict.btnDelete}</span></button>
            </div>"""
    if old_card_actions in content:
        content = content.replace(old_card_actions, new_card_actions)

    old_merged_actions = """            <div class="history-actions" style="display:flex; gap:6px; flex-wrap:wrap; align-items:center; min-width:180px; justify-content:flex-end;">
              <button class="primary-btn" style="padding:6px 12px; font-size:0.8rem; background:linear-gradient(135deg, #8b5cf6, #6366f1); border-color:#8b5cf6;" onclick="copyHistoryConvertedUrl('${item.url}', 'auto')" title="${dict.btnCopyMerged}">${dict.btnCopyMerged}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#38bdf8; border-color:rgba(56,189,248,0.4);" onclick="importHistoryToFlClash('${item.url}')">${dict.btnImportCardFlclash}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#a78bfa; border-color:rgba(167,139,250,0.4);" onclick="previewHistoryItem('${item.url}')">${dict.btnPreviewPlain}</button>
              <button class="secondary-btn emerald" style="padding:6px 10px; font-size:0.8rem;" onclick="loadHistoryItem('${item.url}')">${dict.btnLoadHub}</button>
              <button class="secondary-btn" style="padding:6px 8px; font-size:0.8rem; color:#f87171; border-color:rgba(248,113,113,0.3);" onclick="deleteHistoryItem(${idx})" title="${dict.btnDissolve}">${dict.btnDissolve}</button>
            </div>"""

    new_merged_actions = """            <div class="card-action-bar">
              <button class="action-btn primary" onclick="copyHistoryConvertedUrl('${item.url}', 'auto')" title="${dict.btnCopyMerged}">👑 <span>${dict.btnCopyMerged}</span></button>
              <button class="action-btn" onclick="importHistoryToFlClash('${item.url}')" title="${dict.btnImportCardFlclash}">🚀 <span>${dict.btnImportCardFlclash}</span></button>
              <button class="action-btn" onclick="loadHistoryItem('${item.url}')" title="${dict.btnLoadHub}">⚡ <span>${dict.btnLoadHub}</span></button>
              <button class="action-btn" onclick="previewHistoryItem('${item.url}')" title="${dict.btnPreviewPlain}">👀 <span>${dict.btnPreviewPlain}</span></button>
              <button class="action-btn danger" onclick="deleteHistoryItem(${idx})" title="${dict.btnDissolve}">🗑️ <span>${dict.btnDissolve}</span></button>
            </div>"""
    if old_merged_actions in content:
        content = content.replace(old_merged_actions, new_merged_actions)

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Successfully patched index.html with flat UI, origin-aware copying, and real traffic parsing!")

if __name__ == "__main__":
    patch_index_html()
