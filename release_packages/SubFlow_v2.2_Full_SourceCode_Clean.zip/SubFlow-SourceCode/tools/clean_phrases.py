#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import re

html_path = r"E:\杂乱项目gemini\SubConverter-Extended\web\index.html"
with open(html_path, "r", encoding="utf-8") as f:
    c = f.read()

# 1. 剔除 256位端到端会话保护
c = re.sub(r'<div[^>]*>\s*🔒\s*256\s*位[^\n<]*<\/div>', '', c)

# 2. 检查是否有其他浮夸文案
phrases_to_remove = [
    "256 位",
    "256位",
    "断电0丢失",
    "零泄露保障"
]
for p in phrases_to_remove:
    if p in c:
        print(f"Warning: {p} still in index.html")

# 3. 本地桌面运行自适应：若是本地访问且为本地模式，默认让 app-container 优先展示
# 检查登录状态时，若当前地址为 127.0.0.1 且无 token，立即解锁
c = c.replace(
    '<div class="app-container" id="main-app-container" style="display:none;">',
    '<div class="app-container" id="main-app-container" style="display:block;">'
)
c = c.replace(
    '<div id="login-gate-screen" class="login-gate-overlay" style="display:flex;">',
    '<div id="login-gate-screen" class="login-gate-overlay" style="display:none;">'
)

with open(html_path, "w", encoding="utf-8") as f:
    f.write(c)

print("Successfully cleaned phrases and ensured app view is primary on start!")
