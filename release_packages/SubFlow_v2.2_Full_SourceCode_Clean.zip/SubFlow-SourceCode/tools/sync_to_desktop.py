#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import shutil

def sync():
    root = r"E:\杂乱项目gemini\SubConverter-Extended"
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")

    target_dirs = [
        os.path.join(desktop, "SubFlow订阅流", "SubFlow-v1.0-便携版"),
        os.path.join(desktop, "SubConverter订阅转换器", "SubConverter-2026-便携绿色版")
    ]

    files_to_sync = [
        ("web/index.html", "web/index.html"),
        ("web/admin.html", "web/admin.html"),
        ("web/subflow_v2.js", "web/subflow_v2.js"),
        ("web/qrcode.min.js", "web/qrcode.min.js"),
        ("linux/gateway.py", "linux/gateway.py"),
    ]

    for t_dir in target_dirs:
        if not os.path.exists(t_dir):
            continue
        print(f"Syncing updates to desktop: {t_dir}")
        for src_rel, dst_rel in files_to_sync:
            src_full = os.path.join(root, src_rel)
            dst_full = os.path.join(t_dir, dst_rel)
            if os.path.exists(src_full):
                os.makedirs(os.path.dirname(dst_full), exist_ok=True)
                shutil.copy2(src_full, dst_full)
                print(f"  -> Copied {src_rel} to {dst_rel}")

    print("Desktop sync complete! User data and history safely preserved.")

if __name__ == "__main__":
    sync()
