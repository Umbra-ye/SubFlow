#!/usr/bin/env python3
# -*- coding: utf-8 -*-

file_path = r"E:\杂乱项目gemini\SubConverter-Extended\gateway.py"
with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "RUN_MODE = arg.split" in line:
        lines[i] = '        _m = arg.split("=", 1)[1].strip().lower()\n        RUN_MODE = "local" if _m in ["local", "desktop"] else _m\n'
        print(f"Line replaced at {i+1}")
        break

with open(file_path, "w", encoding="utf-8") as f:
    f.writelines(lines)
